package com.co.empresa.coquito.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootForm1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
