package com.co.empresa.coquito.app.service;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;

import org.springframework.stereotype.Service;


@Service
public class ServiceTxt implements IServicion{
	
	 @Override
	 public String guardarArchivo(String nombre,String cedula,String email, String temperatura, Boolean sintomas){
	        try {
	            String ruta = "C:\\Users\\edwar\\Documents\\txt";
	            String contenido = "Nombre:" + nombre + "Cedula: " + cedula + "email:" + email + "temperatura:" + temperatura + "sintomas:" + sintomas;
	            File file = new File(ruta);
	            // Si el archivo no existe es creado
	            if (!file.exists()) {
	                file.createNewFile();
	            }
	            FileWriter fw = new FileWriter(file);
	            BufferedWriter bw = new BufferedWriter(fw);
	            bw.write(contenido);
	            bw.close();
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    return "Se a creado el archivo txt";
	}
	
}
