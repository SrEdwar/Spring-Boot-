package com.co.empresa.coquito.app.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.co.empresa.coquito.app.models.Usuario;

@Controller
@RequestMapping(value = "/registroCoquito")
public class RegistroController {
	
	@Value("${texto.RegistroController.Titulo}")
	private String titulo;
	@Value("${texto.RegistroController.Nombre}")
	private String nombre;
	@Value("${texto.RegistroController.Cedula}")
	private String cedula;
	@Value("${texto.RegistroController.Email}")
	private String email;
	@Value("${texto.RegistroController.Temperatura}")
	private String temperatura;
	@Value("${texto.RegistroController.Sintomas}")
	private String sintomas;
	@Value("${texto.RegistroController.Radio}")
	private String radio;
	@Value("${texto.RegistroController.Radio2}")
	private String radio2;
	

	@GetMapping({ "", "/" })
	public String registro(Model model) {

		model.addAttribute("titulo", titulo);
		model.addAttribute("nombre", nombre);
		model.addAttribute("cedula", cedula);
		model.addAttribute("email", email);
		model.addAttribute("temperatura", temperatura);
		model.addAttribute("sintomas", sintomas);
		model.addAttribute("radio",radio);
		model.addAttribute("radio2",radio2);
		
		model.addAttribute("usuario", new Usuario());
		return "registro";
	}

	

}
