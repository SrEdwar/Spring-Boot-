package com.co.empresa.coquito.app.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.co.empresa.coquito.app.models.Usuario;
import com.co.empresa.coquito.app.service.IServicion;

@Controller
@RequestMapping(value = "/registroCoquito")
public class ResultadoController {
	
	@Autowired
	IServicion iServicion;
	

	@Value("${texto.ResultadoController.Titulo}")
	private String titulo;
	@Value("${texto.ResultadoController.Mensaje}")
	private String mensaje;

	@PostMapping("/registrarUsuario")
	public String registrarUsuario(Model model, @Valid Usuario usuario, BindingResult result) {

		model.addAttribute("titulo", titulo);
		model.addAttribute("mensaje", mensaje);
//		if (result.hasErrors()) {
//			Map<String, String> errores = new HashMap<>();
//			result.getFieldErrors().forEach(err -> {
//				errores.put(err.getField(), "El campo " + err.getField() + " no cumple con las validaciones");
//			});
//
//			model.addAttribute("error", errores);
//
//			return "registro";
//
//		}
		
		if(result.hasErrors()) {
			return "registro";
			
		}
		

		String resultad = iServicion.guardarArchivo(usuario.getNombre(), usuario.getCedula(), usuario.getEmail(),
				usuario.getTemperatura(),usuario.getSintomas());
		model.addAttribute("archivo",resultad);
		model.addAttribute("usuario", usuario);

		return "resultado";

	}

}
