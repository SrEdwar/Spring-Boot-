package com.co.empresa.coquito.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootForm1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootForm1Application.class, args);
	}

}
