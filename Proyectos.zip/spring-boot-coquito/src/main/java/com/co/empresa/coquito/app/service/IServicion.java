package com.co.empresa.coquito.app.service;

public interface IServicion {
	
	String guardarArchivo(String nombre,String cedula,String email, String temperatura, Boolean sintomas);

}
