package com.co.empresa.coquito.app.models;

import javax.validation.constraints.NotEmpty;

public class Usuario {
	@NotEmpty
	private String nombre;
	@NotEmpty
	private String cedula;
	private String email;
	@NotEmpty
	private String temperatura;
	private Boolean sintomas;
	
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getCedula() {
		return cedula;
	}
	public void setCedula(String cedula) {
		this.cedula = cedula;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getTemperatura() {
		return temperatura;
	}
	public void setTemperatura(String temperatura) {
		this.temperatura = temperatura;
	}
	public Boolean getSintomas() {
		return sintomas;
	}
	public void setSintomas(Boolean sintomas) {
		this.sintomas = sintomas;
	}
	
	

}
