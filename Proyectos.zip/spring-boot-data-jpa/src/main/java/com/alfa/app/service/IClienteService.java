package com.alfa.app.service;

import java.util.List;

import com.alfa.app.models.entity.Cliente;

public interface IClienteService {
	
	public List<Cliente> findAll();
	public void save(Cliente cliente);
	Cliente findCliente(Long id);
	void delete(Long id);
	
	

}
