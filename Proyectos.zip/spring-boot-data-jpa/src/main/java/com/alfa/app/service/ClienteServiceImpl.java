package com.alfa.app.service;

import java.util.List;

import org.springframework.transaction.annotation.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alfa.app.dao.IClienteDao;
import com.alfa.app.models.entity.Cliente;

@Service
public class ClienteServiceImpl implements IClienteService {

	@Autowired
	private IClienteDao clienteDao;

	@Override
	@Transactional(readOnly = true)
	public List<Cliente> findAll() {

		return clienteDao.findAll();
	}
	
	@Override
	@Transactional(readOnly = true)
	public Cliente findCliente(Long id) {
		return clienteDao.findById(id);
	}

	@Override
	@Transactional
	public void save(Cliente cliente) {

		if (cliente.getId() != null && cliente.getId() > 0) {
			clienteDao.update(cliente);
		} else {
			clienteDao.save(cliente);
		}

	}
	
	@Override
	@Transactional
	public void delete (Long id) {
		Cliente cliente = clienteDao.findById(id);
		clienteDao.delete(cliente);
	}

}
