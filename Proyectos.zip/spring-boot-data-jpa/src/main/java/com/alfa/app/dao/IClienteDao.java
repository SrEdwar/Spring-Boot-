package com.alfa.app.dao;

import java.util.List;

import com.alfa.app.models.entity.Cliente;

public interface IClienteDao {

	public List<Cliente> findAll();

	public void save(Cliente cliente);

	Cliente findById(Long id);

	void update(Cliente cliente);

	void delete(Cliente cliente);

}
