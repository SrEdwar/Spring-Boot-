/*llenar tablas */
INSERT INTO clientes (id,nombre,apellido,email,CREATE_AT) VALUES (1,'Andres','martinez', 'andres@gmail.com','2020-11-14');
 