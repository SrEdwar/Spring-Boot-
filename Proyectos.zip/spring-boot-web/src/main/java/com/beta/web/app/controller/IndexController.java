package com.beta.web.app.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.beta.web.app.models.Ciudad;
import com.beta.web.app.models.Usuario;

@Controller
@RequestMapping(value = "/app")
public class IndexController {

	@Value("${texto.IndexController.tituloIndex}")
	private String textoIndex;
	@Value("${texto.IndexController.tituloPerfil}")
	private String textoPerfil;
	@Value("${texto.IndexController.listadoUsuarios}")
	private String textoListar;

	@GetMapping(value = { "/index", "/home", "/" })
	public String index(Model model) {
		model.addAttribute("titulo", textoIndex);

		return "index";
	}

	@GetMapping(value = "/index2")
	public String home(Model model) {
		model.addAttribute("titulo2", "Hola soy un texto de ejemplo");

		return "index2";
	}

	@GetMapping(value = "/index3")
	public String categories(Model model) {
		model.addAttribute("titulo3", "Hola soy un texto en teoría, largo");

		return "index3";
	}

	@RequestMapping(value = "/perfil")
	public String Perfil(Model model) {

		Usuario usuario = new Usuario();
		usuario.setNombre("Javier");
		usuario.setApellido("Ramirez");
		usuario.setEmail("javier@gmail.com");

		model.addAttribute("usuarioVista", usuario);
		model.addAttribute("titulo", textoPerfil + usuario.getNombre());

		return "perfil";

	}

	@GetMapping(value = "/listarUsuarios")
	public String ListarUsuarios(Model model) {

		List<Usuario> listaUsuarios = new ArrayList<>();

		listaUsuarios.add(new Usuario("Juan", "Martinez", "juan@gmail.com"));
		listaUsuarios.add(new Usuario("Sergio", "GArcia", "sergiio@gmail.com"));
		listaUsuarios.add(new Usuario("messi", "leo", "leom@gmail.com"));

		model.addAttribute("titulo", textoListar);
		model.addAttribute("listaUsuarios", listaUsuarios);

		return "usuarios";

	}

	@ModelAttribute("ciudades")
	public List<Ciudad> poblarCiudades() {

		List<Ciudad> ListaCiudades = Arrays.asList(new Ciudad("Jinx", "Antioquia"), new Ciudad("Aphelios", "Valle"),
				new Ciudad("Vayne", "Valle"), new Ciudad("Tristana", "Anntioquia"));

		return ListaCiudades;
	}

}
