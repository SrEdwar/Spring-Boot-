package com.beta.web.app.models;

public class Ciudad {
		private String nombreCiudad;
		private String nombreDepartamento;
		
		public Ciudad(String nombreCiudad, String nombreDepartamento) {
			
			this.nombreCiudad = nombreCiudad;
			this.nombreDepartamento = nombreDepartamento;
			
		}
		
		public String getNombreCiudad() {
			return nombreCiudad;
		}
		public void setNombreCiudad(String nombreCiudad) {
			this.nombreCiudad = nombreCiudad;
		}
		public String getNombreDepartamento() {
			return nombreDepartamento;
		}
		public void setNombreDepartamento(String nombreDepartamento) {
			this.nombreDepartamento = nombreDepartamento;
		}
		
		
	
}
