package com.beta.web.app.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
@RequestMapping("/variable")
public class EjemploVariablesRutaController {
	
	@GetMapping({"/","/index"})
	public String index(Model model) {
		
		model.addAttribute("titulo","Recibir parametros de la ruta handler por @pathVariable");
		
		return "variable/index";
	}
	
	@GetMapping("/enviarString/{texto}")
	public String  variables(@PathVariable String texto,Model model) {
		
		 model.addAttribute("tituloVer","Recibir parametros de la ruta handler por @pathVariable");
		 model.addAttribute("resultado","El texto enviado es:"+texto );
		
		
		return "variable/ver";
		
	}
	
	@GetMapping("/enviarString/{texto}/{numero}")
	public String  variables(@PathVariable String texto,@PathVariable(name="numero") Integer num ,Model model) {
		
		 model.addAttribute("tituloVer","Recibir parametros de la ruta handler por @pathVariable");
		 model.addAttribute("resultado","El texto enviado es:"+texto + "y el numero:"+ num);
		
		
		return "variable/ver";
		
	}


}
