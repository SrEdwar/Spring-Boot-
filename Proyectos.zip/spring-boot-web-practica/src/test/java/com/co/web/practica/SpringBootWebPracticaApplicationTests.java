package com.co.web.practica;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootWebPracticaApplicationTests {

	@Test
	void contextLoads() {
	}

}
