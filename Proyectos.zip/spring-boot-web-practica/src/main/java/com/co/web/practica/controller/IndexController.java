package com.co.web.practica.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class IndexController {
	
	@Value("${texto.IndexController.tituloIndex}")
	private String textoIndex;
	@Value("${texto.IndexController.Ciudad.Antioquia}")
	private String textoAntio;
	@Value("${texto.IndexController.Ciudad.Valle}")
	private String textoValle;
	@Value("${texto.IndexController.Principal}")
	private String home;
	
	@GetMapping(value = {"/index","/home",""})
	public String index(Model model) {
		
		model.addAttribute("home",home);
		model.addAttribute("titulo",textoIndex);
		model.addAttribute("tituloAn",textoAntio);
		model.addAttribute("tituloVa",textoValle);
		
		return "index";
	}
	
}
