package com.co.web.practica;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootWebPracticaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootWebPracticaApplication.class, args);
	}

}
