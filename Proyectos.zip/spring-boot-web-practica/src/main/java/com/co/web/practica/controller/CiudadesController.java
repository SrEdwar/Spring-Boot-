package com.co.web.practica.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/ciudad")
public class CiudadesController {
	
	@Value("${texto.CiudadesController.Principal}")
	private String principal;
	@Value("${texto.CiudadesController.Principal2}")
	private String principal2;
	@Value("${texto.CiudadesController.tituloCiudad.Antioquia}")
	private String textoA;
	@Value("${texto.CiudadesController.tituloCiudad.Valle}")
	private String textoB;
	@Value("${texto.CiudadesController.Principales.Antioquia}")
    private String princiA;
	@Value("${texto.CiudadesController.Principales.Valle}")
    private String princiV;
	@Value("${texto.SedesController.Titulo}")
	private String link;
	
	
	
	
	
	@GetMapping(value=("/antioquia"))
	public String ciudadAntioquia(@RequestParam(name="texto",required = false, defaultValue = "") String texto,Model model) {
		
		model.addAttribute("home", principal);
		model.addAttribute("titulo",textoA +texto);
		model.addAttribute("princi",princiA);
		model.addAttribute("sede",link);
		
		return "ciudades";
		
	}
	
	@GetMapping({"/valle/{textos}","/valle"})
	public String ciudadValle(@PathVariable(required = false) String textos,Model model) {
		
		model.addAttribute("home", principal2);
		model.addAttribute("titulo",textoB + textos);
		model.addAttribute("princi",princiV);
		model.addAttribute("sede",link);
		
		return "ciudades";
		
	}

}
