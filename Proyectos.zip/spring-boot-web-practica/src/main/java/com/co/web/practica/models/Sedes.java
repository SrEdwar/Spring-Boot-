package com.co.web.practica.models;

public class Sedes {
	private String nombreSede;
	private String departamento;
	
	public Sedes(String nombreSede, String departamento) {
		this.departamento = departamento;
		this.nombreSede = nombreSede;
		
	}
	
	public String getNombreSede() {
		return nombreSede;
	}
	public void setNombreSede(String nombreSede) {
		this.nombreSede = nombreSede;
	}
	public String getDepartamento() {
		return departamento;
	}
	public void setDepartamento(String departamento) {
		this.departamento = departamento;
	}
	
	
}
