package com.co.web.practica.controller;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.co.web.practica.models.Sedes;

@Controller
@RequestMapping({"/ciudad/antioquia","/ciudad/valle","/ciudad"})
public class SedesController {
	
	@Value("${texto.SedesController.Principal}")
	private String home;
	@Value("${texto.SedesController.Titulo}")
	private String titulo;
	@Value("${texto.SedesController.TiTuloTabla}")
	private String tituloTa;
	@Value("${texto.SedesController.TiTuloTabla1}")
	private String tituloTa1;
	@Value("${texto.SedesController.Departamento1}")
	private String depar1;
	@Value("${texto.SedesController.Departamento2}")
	private String depar2;
	@Value("${texto.SedesController.Dato1}")
	private String dato1;
	@Value("${texto.SedesController.Dato2}")
	private String dato2;
	@Value("${texto.SedesController.Dato3}")
	private String dato3;
	@Value("${texto.SedesController.Dato4}")
	private String dato4;
	@Value("${texto.SedesController.Dato5}")
	private String dato5;
	@Value("${texto.SedesController.Dato6}")
	private String dato6;
	
	
	
	@GetMapping("/sedes")
	public String sedes(Model model) {
		model.addAttribute("titulo",titulo);
		model.addAttribute("titloTa",tituloTa);
		model.addAttribute("titloTa1",tituloTa1);
		model.addAttribute("home", home);
		
		return "sedes";
		
	}
	
	 @ModelAttribute("sedesTabla")
	    public List<Sedes> listaSedes() {

	 

	        List<Sedes> ListaSedes = Arrays.asList(new Sedes(dato1, depar1), new Sedes(dato2,depar2),
	                new Sedes(dato3, depar2), new Sedes(dato4, depar1), new Sedes(dato5, depar1), new Sedes(dato6, depar2));

	 

	        return ListaSedes;
	    }

}
