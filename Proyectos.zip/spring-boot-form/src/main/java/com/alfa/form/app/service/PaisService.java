package com.alfa.form.app.service;

import java.util.List;

import com.alfa.form.app.models.Pais;

public interface PaisService {
	
	public List<Pais> listar();

}
