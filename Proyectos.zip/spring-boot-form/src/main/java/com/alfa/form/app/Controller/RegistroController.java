package com.alfa.form.app.Controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;

import com.alfa.form.app.models.Pais;
import com.alfa.form.app.models.Roles;
import com.alfa.form.app.models.Usuario;
import com.alfa.form.app.service.PaisService;
import com.alfa.form.app.service.RolesService;

@Controller
@RequestMapping(value = "/registro")
@SessionAttributes("usuario")
public class RegistroController {
	
	@Autowired
	private PaisService paisService;
	
	@Autowired
	private RolesService roleService;

	@GetMapping({ "", "/" })
	public String registro(Model model) {

		model.addAttribute("titulo", "Registro de Usuario");
		Usuario usuario = new Usuario();
		usuario.setUsername("Ana");
		usuario.setApellido("Martinez");
		usuario.setIdentificador("123-A");
		usuario.setHabilitar(true);
		usuario.setValorSecreto("Algo muy secreto");
		model.addAttribute("usuario",usuario);
		
		return "registro";
	}
	
	@ModelAttribute("paises")
	public List<String> paises(){
		return Arrays.asList("Españan"
				+ "","Mexico","Chile","Argentina","Peru","Colombia","Venezuela");
		
	}
	
	@ModelAttribute("listaPaises")
	public List<Pais> listaPaises(){
		return paisService.listar();
	}
	
	@ModelAttribute("paisesMap")
	public Map<String, String> paisesMap(){
		Map<String, String> paises = new HashMap<String, String>();
		paises.put("ES", "España");
		paises.put("MX", "Mexio");
		paises.put("CL", "Chile");
		paises.put("AR", "Argentina");
		paises.put("PE", "Peru");
		paises.put("CO", "Colombia");
		paises.put("VE", "Venezuela");
		return paises;
	}
	
	
	@ModelAttribute("listaRoles")
	public List<Roles> listaRoles(){
		List<Roles> roles= new ArrayList<>();
		roles.add(new Roles(1,"ROL_ADMIN","administrador"));
		roles.add(new Roles(2,"ROL_USER","usuario"));
		roles.add(new Roles(3,"ROL_MODERATOR","moderador"));
		
		return roles;
		
	}
	
	@ModelAttribute("listaRolesMap")
	public Map<String, String> listaRolesMap(){
		
		
	
		return roleService.listar();
	}
	
	@ModelAttribute("listaRolesString")
	public List<String> listaRolesString(){
		List<String> roles= new ArrayList<>();
		roles.add("ROL_ADMIN");
		roles.add("ROLE_USER");
		roles.add("ROLE_MODERATOR");
		return roles;
		
	}


	@PostMapping("/registrarUsuario")
	public String registrarUsuario(Model model, @Valid Usuario usuario, BindingResult result,SessionStatus status) {

		model.addAttribute("titulo", "Resultado del Registro");
//		if(result.hasErrors()) {
//			Map<String, String> errores = new HashMap<>();
//			result.getFieldErrors().forEach(err ->{
//				errores.put(err.getField(),"El campo " + err.getField() + " no cumple con las validaciones" );
//			});
		
		if(result.hasErrors()) {
			return "registro";
			}
			
			model.addAttribute("usuario", usuario);
			
			return "redirect:/registro/ver";
			
			
			
			
		}
	@GetMapping("/ver")
	public String ver(@SessionAttribute(required = false, name="usuario") Usuario usuario, Model model, SessionStatus status) {
		if(usuario == null) {
			return "redirect:/registro";
		}
		model.addAttribute("titulo", "Resultado del Registro");
		status.setComplete();
		return "resultado";
	}
			
		
		

	}


