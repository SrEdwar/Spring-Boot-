package com.alfa.form.app.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Service;
@Service
public class RolesServiceImpl  implements RolesService{

	@Override
	public Map<String, String> listar() {
		Map<String, String> roles = new HashMap<String, String>();
		roles.put("ROLE_ADMIN", "Administrado");
		roles.put("ROLE_USER", "Usuario");
		roles.put("ROLE_MODERATOR", "Moderador");
		
	
		return roles;
	}

}
