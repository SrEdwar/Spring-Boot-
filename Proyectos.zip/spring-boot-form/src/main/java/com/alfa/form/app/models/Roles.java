package com.alfa.form.app.models;

public class Roles {
	private Integer id;
	private String role;
	private String nombre;
	
	
	
	public Roles() {
		
	}
	
	public Roles(Integer id, String role, String nombre) {
		this.id = id;
		this.role = role;
		this.nombre = nombre;
	}
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	
	

}
