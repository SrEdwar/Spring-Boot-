package com.alfa.form.app.service;


import java.util.Map;

public interface RolesService {

	public Map<String, String> listar();
}
