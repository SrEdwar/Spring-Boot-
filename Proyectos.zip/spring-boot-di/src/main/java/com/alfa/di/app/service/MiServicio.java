package com.alfa.di.app.service;

import org.springframework.stereotype.Service;

@Service("MiServicio")
public class MiServicio implements IServicio {
	
	@Override
	public String realizarOperacion() {
		/*
		 * Realiza mucha cosa de logica de negocio
		 */
		
		return "Resultado de la operacion";
	}

}
