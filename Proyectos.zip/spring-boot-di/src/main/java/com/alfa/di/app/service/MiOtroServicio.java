package com.alfa.di.app.service;



import org.springframework.stereotype.Service;

@Service("MiOtroServicio")
public class MiOtroServicio implements IServicio {
	
	@Override
	public String realizarOperacion() {
		/*
		 * Realiza otra mucha cosa de logica de negocio
		 */
		
		return "Resultado de la operacion de mi otro servico";
	}

}
