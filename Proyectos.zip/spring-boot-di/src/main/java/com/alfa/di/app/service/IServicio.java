package com.alfa.di.app.service;

public interface IServicio {

	String realizarOperacion();

}
