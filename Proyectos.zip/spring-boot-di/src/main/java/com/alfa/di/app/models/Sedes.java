package com.alfa.di.app.models;

public class Sedes {
	private String departamento;
	private String nombreSede;
	
	public Sedes(String departemento,String nombreSede) {
		this.departamento = departemento;
		this.nombreSede = nombreSede;
	}
	
	public String getDepartamento() {
		return departamento;
	}
	public void setDepartamento(String departamento) {
		this.departamento = departamento;
	}
	public String getNombreSede() {
		return nombreSede;
	}
	public void setNombreSede(String nombreSede) {
		this.nombreSede = nombreSede;
	}
	
	
}
