package com.alfa.di.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.alfa.di.app.service.IServicio;

@Controller
@RequestMapping("di")
public class IndexController {
	
	@Autowired
	@Qualifier("MiOtroServicio")
	IServicio iServicio;
	
	@GetMapping({"","index","/"})
	public String index(Model model) {
		
		String resultado = iServicio.realizarOperacion();
		model.addAttribute("operacionRealizada",resultado);
		return "index";
	}

}
