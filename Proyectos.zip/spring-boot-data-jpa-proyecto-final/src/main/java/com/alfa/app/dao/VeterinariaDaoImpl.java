package com.alfa.app.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;


import com.alfa.app.models.entity.Veterinaria;

@Repository
public class VeterinariaDaoImpl implements IVeterinariaDao{
	
	@PersistenceContext
	private EntityManager em;

	@SuppressWarnings("unchecked")
	@Override
	public List<Veterinaria> findAll() {

		return em.createQuery("from Veterinaria").getResultList();
	}

	@Override
	public void save(Veterinaria veterinaria) {
		em.persist(veterinaria);

	}
	
	@Override
	public Veterinaria findById(Long id) {
		return em.find(Veterinaria.class, id);
	}
	
	@Override
	public void update(Veterinaria veterinaria) {
		em.merge(veterinaria);
	}
	
	@Override
	public void delete(Veterinaria veterinaria) {
		em.remove(veterinaria);
		
	}


}
