package com.alfa.app.dao;

import java.util.List;

import com.alfa.app.models.entity.Veterinaria;

public interface IVeterinariaDao {

	public List<Veterinaria> findAll();

	public void save(Veterinaria veterinaria);

	Veterinaria findById(Long id);

	void update(Veterinaria veterinaria);

	void delete(Veterinaria veterinaria);

	

}
