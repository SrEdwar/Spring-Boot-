package com.alfa.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootDataJpaProyectoFinalApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootDataJpaProyectoFinalApplication.class, args);
	}

}
