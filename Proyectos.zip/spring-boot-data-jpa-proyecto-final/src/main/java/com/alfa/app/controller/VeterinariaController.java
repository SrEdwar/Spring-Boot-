package com.alfa.app.controller;

import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.support.SessionStatus;

import com.alfa.app.models.entity.Veterinaria;

import com.alfa.app.service.IVeterinariaService;


@Controller
public class VeterinariaController {

	@Autowired
	private IVeterinariaService veterinariaService;

	@RequestMapping(value = "listar", method = RequestMethod.GET)
	public String listar(Model model) {
		model.addAttribute("titulo", "Listado de clientes");
		model.addAttribute("veterinaria", veterinariaService.findAll());
		return "listar";

	}

	@RequestMapping(value = "/form")
	public String crear(Map<String, Object> model) {
		Veterinaria veterinaria = new Veterinaria();
		model.put("veterinaria", veterinaria);
		model.put("titulo", "Formulario de Ingreso");
		return "form";

	}

	@RequestMapping(value = { "", "/","index" })
	public String index(Model model) {
		model.addAttribute("titulo", "Veterinaria");

		return "index";
	}

	@RequestMapping(value = "/form", method = RequestMethod.POST)
	public String guardar(Model model, @Valid Veterinaria veterinaria, BindingResult result,SessionStatus status) {
		
		if(result.hasErrors()) {
			return "/form";
			}
			
			model.addAttribute("veterinaria", veterinaria);
			veterinariaService.save(veterinaria);
			
			return "redirect:/listar";
		
	}

	@RequestMapping(value = "/form/{id}")
	public String editar(Map<String, Object> model, @PathVariable(value = "id") Long id) {
		Veterinaria veterinaria = null;
		if (id > 0) {
			veterinaria = veterinariaService.findVeterinaria(id);
		} else {
			return "redirect:/listar";
		}

		model.put("veterinaria", veterinaria);
		model.put("titulo", "Editar");
		return "form";

	}

	@RequestMapping(value = "/eliminar/{id}")
	public String eliminar(Map<String, Object> model, @PathVariable(value = "id") Long id) {

		if (id > 0) {

			veterinariaService.delete(id);

		}
		return "redirect:/listar";

	}

}
