package com.alfa.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import com.alfa.app.dao.IVeterinariaDao;
import com.alfa.app.models.entity.Veterinaria;

@Service
public class VeterinariaServiceImpl implements IVeterinariaService {
	
	@Autowired
	private IVeterinariaDao veterinariaDao;

	@Override
	@Transactional(readOnly = true)
	public List<Veterinaria> findAll() {

		return veterinariaDao.findAll();
	}
	
	@Override
	@Transactional(readOnly = true)
	public Veterinaria findVeterinaria(Long id) {
		return veterinariaDao.findById(id);
	}

	@Override
	@Transactional
	public void save(Veterinaria veterinaria) {

		if (veterinaria.getId() != null && veterinaria.getId() > 0) {
			veterinariaDao.update(veterinaria);
		} else {
			veterinariaDao.save(veterinaria);
		}

	}
	
	@Override
	@Transactional
	public void delete (Long id) {
		Veterinaria veterinaria = veterinariaDao.findById(id);
		veterinariaDao.delete(veterinaria);
	}



}
