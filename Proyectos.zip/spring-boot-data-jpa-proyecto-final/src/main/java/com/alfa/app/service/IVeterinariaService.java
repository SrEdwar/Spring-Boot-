package com.alfa.app.service;

import java.util.List;

import com.alfa.app.models.entity.Veterinaria;

public interface IVeterinariaService {

	public List<Veterinaria> findAll();
	public void save(Veterinaria veterinaria);
	Veterinaria findVeterinaria(Long id);
	void delete(Long id);

}
